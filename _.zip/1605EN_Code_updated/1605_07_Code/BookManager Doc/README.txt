Book Manager Application (beta release)
---------------------------------------

BookManager application helps Admins and Users to organize books and
 publishing details. Admins can add, delete and modify a book's 
details while user will be able list the books.

#Features List :

##Admin :
Add, modify and Delete books
List all the available books
Export Books to CSV or XML
Demo data for the fisrt time set up
##User 
List all teh available books
##General
About screen for the application

Note : This application is developed with the powerful features of
Rational Team Concert 2.0.0.x.