package server.beans;

public class BooklookUser
{
    public Long user_id;
    public String username;
    public String password;
    public String usertype;
    
    public Long getUser_id()
    {
        return user_id;
    }
    public void setUser_id(Long userId)
    {
        user_id = userId;
    }
    public String getUsername()
    {
        return username;
    }
    public void setUsername(String username)
    {
        this.username = username;
    }
    
    public String getPassword()
    {
        return password;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    public String getUsertype()
    {
        return usertype;
    }
    public void setUsertype(String usertype)
    {
        this.usertype = usertype;
    }
}
